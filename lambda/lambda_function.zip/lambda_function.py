import json
import os
import boto3

sqs = boto3.client('sqs')
SQS_QUEUE_URL = os.environ['SQS_QUEUE_URL']

def lambda_handler(event, context):
    try:
        body = json.loads(event['body'])
        reply_to = body['reply_to']
        inputs = body['inputs']
        
        if 'type' in inputs and inputs['type'] == 'name':
            payload = {
                "set": {
                    "name": inputs['value']
                }
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Invalid input type'})
            }
        
        response = sqs.send_message(
            QueueUrl=SQS_QUEUE_URL,
            MessageBody=json.dumps(payload)
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({'message_id': response['MessageId']})
        }
        
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': f'Missing required field: {str(e)}'})
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }